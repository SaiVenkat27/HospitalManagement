from django.shortcuts import render,redirect

from django.utils import timezone

from .models import *

# Create your views here.
def about(request):
	usern = request.session['username']
	print(usern)
	# usern = {'usern': usern}
	return render(request,'about.html')

def prescription(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		user = request.session['username']
		pa = Prescription.objects.filter(doctor__name=user)
		p = pa.order_by('-date2')
		p = {'p':p}

		return render(request,'prescriptions.html',p)


def appointment(request):

	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		user = request.session['username']
		
		now = timezone.now()
		ma = Appointment.objects.filter(doctor__name=user)
		ap = ma.filter(date1__gte=now).order_by('date1')
		ad = ma.filter(date1__lt=now).order_by('-date1')
		a = {'ap' : ap, 'ad': ad}
		print(a)
		
		return render(request,'appointments.html',a)

def login(request):
	error = ''
	if request.method == 'POST':
		n = request.POST.get('name')
		p = request.POST.get('pwd')
		person = request.POST.get('person')
		print(person)
		if person == '0':
			doc = Doctor.objects.get(name=n)
			if doc.password == p :
				request.session['username'] = n

				return redirect('prescription')
			else:
				print("Boo")
		elif person == '1':
			print('patient')
			pat = Patient.objects.get(name=n)
			if pat.password == p :
				print('ckeck')
				request.session['username'] = n

				return redirect('medical')
			else:
				print("Boo")

		elif person == '2':
			hr = HR.objects.get(name=n)
			if hr.password == p :
				request.session['username'] = n

				return redirect('view_doctor')
			else:
				print("Boo")

		elif person == '3':
			recep = Reception.objects.get(name=n)
			if recep.password == p :
				request.session['username'] = n

				return redirect('appointment_recep')
			else:
				print("Boo")

		
	return render(request,'login.html')
def logout(request):
	request.session.pop("username",None)
	return redirect('login')

def register(request):
	error = ""
	if request.method == 'POST':
		n = request.POST.get('name')
		g = request.POST.get('gender')
		m = request.POST.get('mobile')
		p = request.POST.get('pwd')
		a = request.POST.get('age')
		v = request.POST.get('details')
		if v == '0':
			try:
				Doctor.objects.create(name = n,gender = g, mobile = m,age=a,password= p)
				error = 'no'
				return redirect('login')
			except:
				error = 'yes'
		elif v == '1':
			try:
				Patient.objects.create(name = n,gender = g, mobile = m,age=a,password= p)
				error = 'no'
				return redirect('login')
			except:
				error = 'yes'
	d = {'error' : error}
	return render(request,'register.html',d)


def create_appo(request):
	# print("workss")
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	error = ""
	if request.method == 'POST':
		docn = request.session['username']
		patient_n = request.POST.get('name')
		sym = request.POST.get('symptoms')
		pres = request.POST.get('prescription')
		dat = request.POST.get('date2')
		# print(docn,patient_n,sym,pres,dat)
		try:
			# print("done")
			d = Doctor.objects.get(name=docn)
			p = Patient.objects.get(name=patient_n)
			# addd = Prescription(doctor=docn)
			# add.save()
			Prescription.objects.create(doctor=d,patient=p,symptoms=sym,prescription=pres,date2=dat)
			# print("done")
			error = 'no'
			return redirect('prescription')
		except:
			error = 'yes'
	d = {'error' : error}
		

	return render(request,'create_appo.html',d)	


def hr(request):
	return render(request,'hr.html')

def patient(request):
	return render(request,'patient.html')

def Recep(request):
	return render(request,'Recep.html')

def medical(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		user = request.session['username']
		pp = Prescription.objects.filter(patient__name=user)
		a = pp.order_by('-date2')
		a= {'a':a}
	return render(request,'medical.html',a)


def appointment_patients(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		user = request.session['username']
		
		now = timezone.now()
		ma = Appointment.objects.filter(patient__name=user)
		ap = ma.filter(date1__gte=now).order_by('date1')
		ad = ma.filter(date1__lt=now).order_by('-date1')
		a = {'ap' : ap, 'ad': ad}
		print(a)
		
		return render(request,'appointment_patients.html',a)


def invoice_patients(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		user = request.session['username']
		pp = Invoice.objects.filter(patient__name=user)
		a = pp.order_by('-date3')
		a= {'a':a}
	return render(request,'invoice_patients.html',a)


def create_appointment_hr(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	error = ""
	if request.method == 'POST':
		docn = request.POST.get('doctor')
		patient_n = request.POST.get('patient')
		date4 = request.POST.get('date4')
		time4 = request.POST.get('time4')
		
		# print(docn,patient_n,sym,pres,dat)
		try:
			# print("done")
			d = Doctor.objects.get(name=docn)
			p = Patient.objects.get(name=patient_n)
			# addd = Prescription(doctor=docn)
			# add.save()
			Appointment.objects.create(doctor=d,patient=p,date1=date4,time1=time4)
			# print("done")
			error = 'no'
			return redirect('appointment_recep')
		except:
			error = 'yes'
	d = {'error' : error}

	return render(request,'create_appointment_hr.html')


def appointment_recep(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		
		
		now = timezone.now()
		ma = Appointment.objects.all()
		ap = ma.filter(date1__gte=now).order_by('date1')
		ad = ma.filter(date1__lt=now).order_by('-date1')
		a = {'ap' : ap, 'ad': ad}
		print(a)
		
		return render(request,'appointment_recep.html',a)


def patient_view(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		
		
		
		ma = Patient.objects.all()
		
		ma = {'ma' : ma}
		
		return render(request,'patient_view.html',ma)


def new_patient(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	error = ""
	if request.method == 'POST':
		age = request.POST.get('age')
		patient_n = request.POST.get('patient')
		pwd = 'password'
		gender = request.POST.get('gender')
		mobile = request.POST.get('mobile')
		
		# print(docn,patient_n,sym,pres,dat)
		try:
			# print("done")
			
			# addd = Prescription(doctor=docn)
			# add.save()
			Patient.objects.create(name=patient_n,age=age,password=pwd,gender=gender,mobile=mobile)
			# print("done")
			error = 'no'
			return redirect('patient_view')
		except:
			error = 'yes'
	d = {'error' : error}

	return render(request,'new_patient.html',d)

def view_doctor(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	else:
		
		
		
		ma = Doctor.objects.all()
		
		ma = {'ma' : ma}
		
		return render(request,'view_doctor.html',ma)


def new_doctor(request):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	error = ""
	if request.method == 'POST':
		age = request.POST.get('age')
		doc_n = request.POST.get('doctor')
		pwd = 'password'
		gender = request.POST.get('gender')
		mobile = request.POST.get('mobile')
		
		# print(docn,patient_n,sym,pres,dat)
		try:
			# print("done")
			
			# addd = Prescription(doctor=docn)
			# add.save()
			Doctor.objects.create(name=doc_n,age=age,password=pwd,gender=gender,mobile=mobile)
			# print("done")
			error = 'no'
			return redirect('view_doctor')
		except:
			error = 'yes'
	d = {'error' : error}

	return render(request,'new_doctor.html',d)


def delete_doctor(request,id):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	doc = Doctor.objects.get(id= id)
	print(doc)
	doc.delete()
	return redirect(request,'view_doctor')

def delete_patient(request,id):
	if not 'username' in request.session:
		# print('lol')
		return redirect('login')
	doc = Patient.objects.get(id= id)
	doc.delete()
	return redirect(request,'patient_view')