from django.contrib import admin

# Register your models here.
from .models import *


admin.site.register(Doctor)
admin.site.register(Patient)
admin.site.register(Appointment)
admin.site.register(Prescription)
admin.site.register(HR)
admin.site.register(Reception)
admin.site.register(Invoice)