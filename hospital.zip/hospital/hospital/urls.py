"""hospital URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from doctors.views import *

urlpatterns = [
    path('', login,name='home'),
    path('admin/', admin.site.urls),
    path('about/', about,name='about'),
    path('login/', login,name='login'),

    path('register/', register),
    path('prescription/', prescription,name='prescription'),
    path('appointment/', appointment,name='appointment'),
    path('logout/', logout,name='logout'),
    path('create_appo/', create_appo,name='create_appo'),
    path('hr/', hr,name='hr'),
    path('Recep/', Recep,name='Recep'),
    path('patient/', patient,name='patient'),
    path('medical/', medical,name='medical'),
    path('appointment_patients/', appointment_patients,name='appointment_patients'),
    path('invoice_patients/', invoice_patients,name='invoice_patients'),
    path('create_appointment_hr/', create_appointment_hr,name='create_appointment_hr'),
    path('appointment_recep/', appointment_recep,name='appointment_recep'),
    path('patient_view/', patient_view,name='patient_view'),
    path('new_patient/', new_patient,name='new_patient'),
    path('new_doctor/', new_doctor,name='new_doctor'),
    path('view_doctor/', view_doctor,name='view_doctor'),
    path('delete_doctor/<int:id>/', delete_doctor,name='delete_doctor'),
    path('delete_patient/<int:id>/', delete_patient,name='delete_patient'),    





]
